from pymongo import MongoClient
from bson.objectid import ObjectId
from bson.json_util import dumps

class AnimalShelter(object):
    #creating the CRUD operations in MongoDB
    
    def __init__(self,username,password):
        # connection variables
        USER = 'aacuser'
        PASS = 'SNHU1234'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31761
        DB = 'AAC'
        COL = 'animals'
        
        # Initializing Connection
        self.client = MongoClient('mongodb://%s:%s@%s:%d'%(USER,PASS,HOST,PORT))
        self.database = self.client['%s'%(DB)]
        self.collection = self.database['%s'%(COL)]
        
    # completing the create method
    def create(self, data):
        if data is not None:
            self.database.animals.insert_one(data)
            return True
        else:
            raise Exception("Nothing to save because data parameter is empty")
            
    # completing the read method                              
    def read(self, data):
        # returning the result of the search                          
        if data:
            data = self.database.animals.find(data,{'id':0})
        else:
            data = self.database.animals.find({},{'id':0})
        return data
    
    # completing the update method
    def update(self, data, replace):
        if data is not None:
            self.database.animals.update_many(data,replace)
            print("Updated.")
        else:
            raise Exception("Cannot update.")
            
                    
    # completing the delete method
    def delete(self, data):
        if data is not None:
            for animal in self.database.animals.find(data):
                print(animal)
            self.database.animals.delete_many(data)
        else:
            raise Exception("Can't find anything to delete.")